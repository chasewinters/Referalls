<?php

define('EMAIL_FOR_REPORTS', '');
define('RECAPTCHA_PRIVATE_KEY', '@privatekey@');
define('FINISH_URI', 'http://');
define('FINISH_ACTION', 'message');
define('FINISH_MESSAGE', '');
define('UPLOAD_ALLOWED_FILE_TYPES', 'doc, docx, xls, csv, txt, rtf, html, zip, jpg, jpeg, png, gif');

define('_DIR_', str_replace('\\', '/', dirname(__FILE__)) . '/');
require_once _DIR_ . '/handler.php';

?>

<?php if (frmd_message()): ?>
<link rel="stylesheet" href="<?php echo dirname($form_path); ?>/formoid-default-skyblue.css" type="text/css" />
<span class="alert alert-success"><?php echo FINISH_MESSAGE; ?></span>
<?php else: ?>
<!-- Start Formoid form-->
<link rel="stylesheet" href="<?php echo dirname($form_path); ?>/formoid-default-skyblue.css" type="text/css" />
<script type="text/javascript" src="<?php echo dirname($form_path); ?>/jquery.min.js"></script>
<form class="formoid-default-skyblue" style="background-color:#ffffff;font-size:14px;font-family:'Open Sans','Helvetica Neue','Helvetica',Arial,Verdana,sans-serif;color:#36302f;max-width:400px;min-width:150px" method="post"><div class="title"><h2>Lou Fusz Referral Form</h2></div>
	<div class="element-separator"><hr><h3 class="section-break-title">Prospect Information</h3></div>
	<div class="element-date<?php frmd_add_class("date"); ?>"><label class="title">Date</label><input class="large" data-format="yyyy-mm-dd" type="date" name="date" placeholder="yyyy-mm-dd"/></div>
	<div class="element-input<?php frmd_add_class("input"); ?>"><label class="title">Name</label><input class="large" type="text" name="input" /></div>
	<div class="element-email<?php frmd_add_class("email"); ?>"><label class="title">Email</label><input class="large" type="email" name="email" value="" /></div>
	<div class="element-phone<?php frmd_add_class("phone"); ?>"><label class="title">Phone</label><input class="large" type="tel" pattern="\d{3}-\d{3}-\d{4}" maxlength="24" name="phone" placeholder="XXX-XXX-XXXX" value=""/></div>
	<div class="element-input<?php frmd_add_class("input1"); ?>"><label class="title">Interested in a</label><input class="large" type="text" name="input1" /></div>
	<div class="element-multiple<?php frmd_add_class("multiple"); ?>"><label class="title">Select which store to send you're referral to</label><div class="large"><select data-no-selected="Nothing selected" name="multiple[]" multiple="multiple" >

		<option value="Buick">Buick</option>
		<option value="Chevrolet">Chevrolet</option>
		<option value="CDJR and Fiat">CDJR and Fiat</option>
		<option value="Fiat Metro East">Fiat Metro East</option>
		<option value="Ford">Ford</option>
		<option value="Kia">Kia</option>
		<option value="Mazda">Mazda</option>
		<option value="Mitsubishi">Mitsubishi</option>
		<option value="Subaru Creve Coeur">Subaru Creve Coeur</option>
		<option value="Subaru St Peters">Subaru St Peters</option>
		<option value="Toyota">Toyota</option></select></div></div>
	<div class="element-separator"><hr><h3 class="section-break-title">Your Information</h3></div>
	<div class="element-input<?php frmd_add_class("input2"); ?>"><label class="title">Your Name</label><input class="large" type="text" name="input2" /></div>
	<div class="element-phone<?php frmd_add_class("phone1"); ?>"><label class="title">Your Phone</label><input class="large" type="tel" pattern="[+]?[\.\s\-\(\)\*\#0-9]{3,}" maxlength="24" name="phone1"  value=""/></div>
	<div class="element-multiple<?php frmd_add_class("multiple1"); ?>"><label class="title">Company Affiliation (if fusz employee)</label><div class="large"><select data-no-selected="Nothing selected" name="multiple1[]" multiple="multiple" >

		<option value="Buick">Buick</option>
		<option value="Chevrolet">Chevrolet</option>
		<option value="CDJR and Fiat">CDJR and Fiat</option>
		<option value="Fiat Metro East">Fiat Metro East</option>
		<option value="Ford">Ford</option>
		<option value="Kia">Kia</option>
		<option value="Mazda">Mazda</option>
		<option value="Mitsubishi">Mitsubishi</option>
		<option value="Subaru Creve Coeur">Subaru Creve Coeur</option>
		<option value="Subaru St Peters">Subaru St Peters</option>
		<option value="Toyota">Toyota</option></select></div></div>
	<div class="element-input<?php frmd_add_class("input4"); ?>"><label class="title">Address (if not fusz employee)</label><input class="large" type="text" name="input4" /></div>
	<div class="element-input<?php frmd_add_class("input3"); ?>"><label class="title">Comments</label><input class="large" type="text" name="input3" /></div>
<div class="submit"><input type="submit" value="Submit"/></div></form><script type="text/javascript" src="<?php echo dirname($form_path); ?>/formoid-default-skyblue.js"></script>

<!-- Stop Formoid form-->
<?php endif; ?>

<?php frmd_end_form(); ?>